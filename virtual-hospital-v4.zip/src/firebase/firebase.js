import firebase from "firebase/app";
import "firebase/firestore";
import "firebase/auth";
import "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCTGHSMqmQT8W8IlguWCgfha4Q2XCyQmfU",
  authDomain: "cloudfunc-practice.firebaseapp.com",
  projectId: "cloudfunc-practice",
  storageBucket: "cloudfunc-practice.appspot.com",
  messagingSenderId: "247694367019",
  appId: "1:247694367019:web:0f3a33d06a0af25dd90d6e",
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
export { db, firebase };
